import React from "react";
import { Link } from "react-router-dom";
import { FaTachometerAlt, FaUser, FaChartBar, FaCog } from "react-icons/fa";

const Sidebar = () => {
  return (
    <div className="w-64 bg-blue-800 text-white flex flex-col">
      <div className="p-4 font-bold text-2xl border-b border-blue-700">Admin Panel</div>
      <nav className="flex flex-col p-4 gap-4">
        <Link to="/" className="flex items-center gap-2 p-2 rounded hover:bg-blue-700">
          <FaTachometerAlt />
          Dashboard
        </Link>
        <Link to="/users" className="flex items-center gap-2 p-2 rounded hover:bg-blue-700">
          <FaUser />
          Users
        </Link>
        <Link to="/reports" className="flex items-center gap-2 p-2 rounded hover:bg-blue-700">
          <FaChartBar />
          Reports
        </Link>
        <Link to="/settings" className="flex items-center gap-2 p-2 rounded hover:bg-blue-700">
          <FaCog />
          Settings
        </Link>
      </nav>
    </div>
  );
};

export default Sidebar;