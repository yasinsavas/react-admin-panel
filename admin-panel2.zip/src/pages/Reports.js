import React from "react";

const Reports = () => {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Reports</h1>
      <div className="p-6 bg-white shadow rounded">Reports Content</div>
    </div>
  );
};

export default Reports;