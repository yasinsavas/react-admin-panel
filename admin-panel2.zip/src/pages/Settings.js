import React from "react";

const Settings = () => {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Settings</h1>
      <div className="p-6 bg-white shadow rounded">Settings Content</div>
    </div>
  );
};

export default Settings;