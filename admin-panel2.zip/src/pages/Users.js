import React from "react";

const Users = () => {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Users</h1>
      <div className="p-6 bg-white shadow rounded">User Management Content</div>
    </div>
  );
};

export default Users;