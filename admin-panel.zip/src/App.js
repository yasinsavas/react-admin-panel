import React from 'react';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>Welcome to Admin Panel</h1>
        <p>This is a simple React-based admin panel.</p>
      </header>
    </div>
  );
}

export default App;